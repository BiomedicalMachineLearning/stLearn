# Do not put this into its own module as it’s 99% the same as other functions
# from that module.
from ..plotting._tools.scatterplots import phate
from ..plotting._tools.scatterplots import trimap
