from .adds.add_image import image
from .adds.add_positions import positions
from .adds.parsing import parsing
from .adds.add_lr import lr