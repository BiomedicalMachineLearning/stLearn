===============================
stlearn
===============================

# A downstream analysis toolkit for Spatial Transcriptomic data

# How to install

### Step 1:

``` conda config --add channels conda-forge ```

``` conda install r r-base libopenblas r-elpigraph.r```

### Step 2:

``` pip install stlearn```




