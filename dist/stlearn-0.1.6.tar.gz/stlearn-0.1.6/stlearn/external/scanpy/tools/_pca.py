from ..preprocessing import _simple as pp

pca = pp.pca
