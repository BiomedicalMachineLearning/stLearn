=====
Usage
=====

To use stLearn in a project::

    import stlearn
